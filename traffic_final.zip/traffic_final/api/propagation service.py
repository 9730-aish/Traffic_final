# Road Network Graph topology for Nagpur Junctions (OSM Overpass network model)
ROAD_CONNECTIONS = {
    "Sitabuldi": ["Wardha Road", "Dharampeth", "Sadar", "Medical Square"],
    "Wardha Road": ["Sitabuldi", "Airport Road", "Ring Road", "Hingna Road"],
    "Hingna Road": ["Wardha Road", "Dharampeth", "Ring Road"],
    "Kamptee Road": ["Sadar", "Sitabuldi", "Ring Road"],
    "Manewada": ["Medical Square", "Ring Road", "Wardha Road"],
    "Sadar": ["Sitabuldi", "Kamptee Road", "Dharampeth"],
    "Dharampeth": ["Sitabuldi", "Hingna Road", "Sadar"],
    "Medical Square": ["Sitabuldi", "Manewada", "Ring Road"],
    "Airport Road": ["Wardha Road", "Ring Road"],
    "Ring Road": ["Wardha Road", "Airport Road", "Manewada", "Kamptee Road", "Hingna Road"]
}
def analyze_propagation(location_name, congestion_score, traffic_level):
    """
    Analyzes road-to-road congestion propagation using OpenStreetMap topology.
    Identifies connected corridor risk and spillover potential.
    """
    connected = ROAD_CONNECTIONS.get(location_name, ["Ring Road", "Sitabuldi"])
    
    if congestion_score >= 70 or traffic_level == "HEAVY":
        spillover_risk = "HIGH"
        impact_radius_km = 3.5
        affected_roads = connected[:2]
        propagation_message = f"High risk of congestion spillover from {location_name} to connected corridors ({', '.join(affected_roads)})."
    elif congestion_score >= 40 or traffic_level in ["HIGH", "MODERATE"]:
        spillover_risk = "MEDIUM"
        impact_radius_km = 1.8
        affected_roads = [connected[0]] if connected else []
        propagation_message = f"Moderate traffic pressure building toward {connected[0] if connected else 'adjacent junctions'}."
    else:
        spillover_risk = "LOW"
        impact_radius_km = 0.5
        affected_roads = []
        propagation_message = f"Traffic flow at {location_name} is stable with minimal spillover risk to connected junctions."
    return {
        "source_location": location_name,
        "spillover_risk": spillover_risk,
        "impact_radius_km": impact_radius_km,
        "connected_junctions": connected,
        "high_risk_downstream": affected_roads,
        "propagation_message": propagation_message
    }
