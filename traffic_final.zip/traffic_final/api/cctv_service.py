import random

def get_cctv_vision_feed(location_name="Katol Road", traffic_ratio=65, weather="clear"):
    """
    Simulates real-time YOLO v8 Object Detection & Perception Pipeline for Nagpur CCTV Cameras.
    Generates dynamic bounding boxes, vehicle classifications, and visual anomaly alerts based on live traffic telemetry.
    """
    ratio = float(traffic_ratio)
    
    # Calculate vehicle breakdown from live traffic ratio
    total_vehicles = int(20 + (ratio * 1.1))
    cars_count = int(total_vehicles * 0.45)
    bikes_count = int(total_vehicles * 0.35)
    autos_count = int(total_vehicles * 0.12)
    trucks_count = max(1, int(total_vehicles * 0.08)) if ratio > 40 else 0

    lane_occupancy = min(98.5, max(12.0, round(ratio * 1.15, 1)))

    # Generate synthetic 2D bounding boxes for HTML5 canvas rendering
    bounding_boxes = []
    classes = [
        {"name": "Car", "color": "#22c55e", "count": cars_count},
        {"name": "Motorbike", "color": "#eab308", "count": bikes_count},
        {"name": "Auto Rickshaw", "color": "#38bdf8", "count": autos_count},
        {"name": "Heavy Truck", "color": "#ef4444", "count": trucks_count}
    ]

    # Seed pseudo-random placement based on location string & ratio for consistency
    random.seed(hash(location_name) + int(ratio))

    for item in classes:
        for _ in range(item["count"]):
            x = round(random.uniform(5.0, 85.0), 1)
            y = round(random.uniform(15.0, 80.0), 1)
            w = round(random.uniform(8.0, 14.0) if item["name"] != "Heavy Truck" else random.uniform(16.0, 24.0), 1)
            h = round(random.uniform(10.0, 18.0) if item["name"] != "Heavy Truck" else random.uniform(20.0, 30.0), 1)
            conf = round(random.uniform(88.0, 98.5), 1)
            bounding_boxes.append({
                "class_name": item["name"],
                "color": item["color"],
                "confidence": conf,
                "x": x,
                "y": y,
                "w": w,
                "h": h
            })

    # Anomaly detection logic
    detected_incidents = []
    if ratio >= 70:
        detected_incidents.append(f"⚠️ Heavy Bottleneck & Slow Motion in Lane 2 at {location_name}")
        detected_incidents.append("🚨 High Occupancy Anomaly (Queue > 65m)")
    elif ratio >= 45:
        detected_incidents.append(f"⚠️ Moderate Lane Congestion near {location_name} Junction")
    else:
        detected_incidents.append(f"✅ Smooth Traffic Perception Flow at {location_name}")

    if weather in ["rain", "heavy rain"]:
        detected_incidents.append("🌧️ Wet Asphalt Braking Distance Advisory Active")
    elif weather == "fog":
        detected_incidents.append("🌫️ Reduced Visibility Cam Assist Active")

    cam_id = f"CAM-NGP-{abs(hash(location_name)) % 90 + 10:02d}"

    return {
        "success": True,
        "location": location_name,
        "cam_id": cam_id,
        "traffic_ratio": ratio,
        "total_vehicles_detected": total_vehicles,
        "cars_count": cars_count,
        "bikes_count": bikes_count,
        "autos_count": autos_count,
        "trucks_count": trucks_count,
        "lane_occupancy_percent": lane_occupancy,
        "weather": weather,
        "detected_incidents": detected_incidents,
        "bounding_boxes": bounding_boxes
    }
