﻿def optimize_signal(data):

    traffic_level = str(
        data.get("traffic_level", "MODERATE")
    ).upper()

    queue_length = float(
        data.get("queue_length", 0)
    )

    lane_blockage = float(
        data.get("lane_blockage", 0)
    )

    current_green_time = float(
        data.get("current_green_time", 60)
    )

    if traffic_level == "HEAVY":
        green_time = 90
        signal_action = "Increase Green Time"

    elif traffic_level == "HIGH":
        green_time = 75
        signal_action = "Slightly Increase Green Time"

    elif traffic_level == "MODERATE":
        green_time = 60
        signal_action = "Maintain Balanced Timing"

    else:
        green_time = 45
        signal_action = "Reduce Green Time"

    if queue_length >= 70:
        green_time += 15
        signal_action = "Strongly Increase Green Time"

    elif queue_length >= 40:
        green_time += 10

    if lane_blockage >= 60:
        green_time += 5

    green_time = max(
        30,
        min(120, green_time)
    )

    cycle_time = 150

    red_time = max(
        30,
        cycle_time - green_time
    )

    signal_change = (
        green_time - current_green_time
    )

    if signal_change > 0:

        change_message = (
            f"Increase green time by "
            f"{round(signal_change)} seconds"
        )

    elif signal_change < 0:

        change_message = (
            f"Reduce green time by "
            f"{abs(round(signal_change))} seconds"
        )

    else:

        change_message = (
            "No signal timing change required"
        )

    return {
        "green_time": int(green_time),
        "red_time": int(red_time),
        "cycle_time": int(cycle_time),
        "signal_action": signal_action,
        "signal_change": int(signal_change),
        "change_message": change_message
    }
