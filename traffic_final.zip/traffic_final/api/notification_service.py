import os
import json
import urllib.parse
import urllib.request
import logging
from api.location_service import get_location_coordinates, get_locations
from api.traffic_service import get_live_traffic
from api.weather_service import get_live_weather
from api.risk_explainer import compute_explainable_risk
from api.recommendation_engine import generate_recommendations

logger = logging.getLogger(__name__)

SUBSCRIPTIONS_FILE = os.path.join(os.path.dirname(__file__), "..", "data", "subscriptions.json")

def load_subscriptions():
    """Load subscriptions from JSON file."""
    try:
        if os.path.exists(SUBSCRIPTIONS_FILE):
            with open(SUBSCRIPTIONS_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Error loading subscriptions: {e}")
    return []

def save_subscriptions(subscriptions):
    """Save subscriptions to JSON file."""
    try:
        os.makedirs(os.path.dirname(SUBSCRIPTIONS_FILE), exist_ok=True)
        with open(SUBSCRIPTIONS_FILE, "w") as f:
            json.dump(subscriptions, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving subscriptions: {e}")
        return False

def add_subscription(phone_number, target_location, api_key="", risk_threshold=65):
    """Add or update a location subscription for a phone number."""
    subscriptions = load_subscriptions()
    
    # Check if subscription already exists for this phone and location
    existing = False
    for sub in subscriptions:
        if sub.get("phone_number") == phone_number and sub.get("target_location") == target_location:
            sub["api_key"] = api_key or sub.get("api_key", "")
            sub["risk_threshold"] = risk_threshold
            existing = True
            break
            
    if not existing:
        subscriptions.append({
            "phone_number": phone_number,
            "target_location": target_location,
            "api_key": api_key,
            "risk_threshold": risk_threshold,
            "created_at": "2026-09-12"
        })
        
    save_subscriptions(subscriptions)
    return {"success": True, "message": f"Successfully subscribed to alerts for {target_location}!"}

def format_whatsapp_message(location, risk_score, traffic_level, speed_kmh=25, causes=None, recommendations=None):
    """Format a clean, user-friendly WhatsApp alert message."""
    causes = causes or ["High vehicle density", "Peak hour traffic"]
    recs = recommendations or {}
    alt_route = recs.get("alternate_route", {}).get("route_name", "VIP Road / Amravati Bypass")
    
    risk_emoji = "🔴" if risk_score > 75 else ("🟡" if risk_score > 50 else "🟢")
    
    message = (
        f"🚨 *TrafficTwin AI Destination Alert* 🚨\n\n"
        f"📍 *Target Location:* {location}\n"
        f"{risk_emoji} *Traffic Status:* {traffic_level.upper()} (Risk: {risk_score}%)\n"
        f"🚗 *Average Speed:* ~{speed_kmh} km/h\n\n"
        f"⚠️ *Key Causes:* {', '.join(causes[:2])}\n"
        f"🛣️ *Recommended Alternate:* {alt_route}\n\n"
        f"💡 *Advice:* Plan your departure accordingly to avoid delays!"
    )
    return message

def format_whatsapp_route_message(origin, destination, risk_score, traffic_level, normal_time_min=10, current_time_min=22, speed_kmh=20, causes=None, recommendations=None):
    """Format a route commute alert (e.g. Sitabuldi to Sadar)."""
    causes = causes or ["Junction queue buildup", "High traffic density"]
    recs = recommendations or {}
    alt_route = recs.get("alternate_route", {}).get("route_name", "Residency Road via Sadar Market")
    delay = max(0, current_time_min - normal_time_min)
    
    risk_status = "🔴 HEAVY TRAFFIC" if risk_score > 75 else ("🟡 MODERATE TRAFFIC" if risk_score > 50 else "🟢 CLEAR FLOW")
    
    message = (
        f"🚦 *TrafficTwin AI Commute Alert* 🚦\n\n"
        f"📍 *Route:* {origin} ➔ {destination}\n"
        f"📊 *Condition:* {risk_status} (Risk Score: {risk_score}%)\n\n"
        f"⏱️ *Estimated Travel Time:* {current_time_min} mins (Normal: {normal_time_min} mins, +{delay} min delay)\n"
        f"🚗 *Average Route Speed:* ~{speed_kmh} km/h\n"
        f"⚠️ *Causes:* {', '.join(causes[:2])}\n\n"
        f"🛣️ *Suggested Alternate:* {alt_route}\n"
        f"💡 *AI Advisory:* Take {alt_route} now to save ~{delay} minutes!"
    )
    return message

def check_route_commute(origin="Sitabuldi", destination="Sadar"):
    """Check live traffic for origin to destination commute route."""
    dest_status = check_destination_traffic(destination)
    orig_status = check_destination_traffic(origin)
    
    avg_risk = int((dest_status.get("risk_score", 50) + orig_status.get("risk_score", 50)) / 2)
    traffic_level = "HEAVY" if avg_risk > 75 else ("HIGH" if avg_risk > 60 else ("MODERATE" if avg_risk > 40 else "LOW"))
    
    normal_time = 10
    delay = int(avg_risk * 0.25)
    current_time = normal_time + delay
    speed_kmh = int(max(12, 45 - (avg_risk * 0.35)))
    
    msg_text = format_whatsapp_route_message(
        origin=origin,
        destination=destination,
        risk_score=avg_risk,
        traffic_level=traffic_level,
        normal_time_min=normal_time,
        current_time_min=current_time,
        speed_kmh=speed_kmh,
        causes=dest_status.get("causes", []),
        recommendations=dest_status.get("recommendations", {})
    )
    
    encoded_msg = urllib.parse.quote(msg_text)
    share_url = f"https://wa.me/?text={encoded_msg}"
    
    return {
        "origin": origin,
        "destination": destination,
        "risk_score": avg_risk,
        "traffic_level": traffic_level,
        "normal_time_mins": normal_time,
        "current_time_mins": current_time,
        "delay_mins": delay,
        "speed_kmh": speed_kmh,
        "causes": dest_status.get("causes", []),
        "recommendations": dest_status.get("recommendations", {}),
        "whatsapp_text": msg_text,
        "share_url": share_url
    }

def send_whatsapp_alert(phone_number, api_key, location, risk_score, traffic_level, speed_kmh=25, causes=None, recommendations=None):
    """
    Send WhatsApp message via Callmebot API or generate standard HTTP request.
    If api_key is not provided, returns simulated delivery status for testing.
    """
    msg_text = format_whatsapp_message(location, risk_score, traffic_level, speed_kmh, causes, recommendations)
    
    if not phone_number:
        return {
            "success": False,
            "error": "Phone number is required for WhatsApp alerts."
        }
        
    # Clean phone number (remove +, spaces, dashes)
    clean_phone = "".join(filter(str.isdigit, phone_number))
    if not clean_phone.startswith("91") and len(clean_phone) == 10:
        clean_phone = "91" + clean_phone
        
    # Standard Callmebot WhatsApp API Call
    if api_key:
        try:
            encoded_msg = urllib.parse.quote(msg_text)
            url = f"https://api.callmebot.com/whatsapp.php?phone=+{clean_phone}&text={encoded_msg}&apikey={api_key}"
            
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=8) as response:
                resp_text = response.read().decode('utf-8')
                
            return {
                "success": True,
                "mode": "live_whatsapp",
                "message": f"WhatsApp alert sent successfully to +{clean_phone}!",
                "whatsapp_text": msg_text,
                "api_response": resp_text[:100]
            }
        except Exception as e:
            logger.warning(f"Live WhatsApp call failed: {e}. Falling back to simulation/share link.")
            
    # Fallback / Direct Share URL generation
    encoded_msg = urllib.parse.quote(msg_text)
    share_url = f"https://wa.me/{clean_phone}?text={encoded_msg}"
    
    return {
        "success": True,
        "mode": "simulated_or_share",
        "message": f"Alert formatted for +{clean_phone}. (API Key optional for instant 1-click share)",
        "whatsapp_text": msg_text,
        "share_url": share_url
    }

def generate_whatsapp_share_link(location, risk_score, traffic_level, speed_kmh=25, causes=None, recommendations=None):
    """Generate a 1-click WhatsApp share URL for any contact or group."""
    msg_text = format_whatsapp_message(location, risk_score, traffic_level, speed_kmh, causes, recommendations)
    encoded_msg = urllib.parse.quote(msg_text)
    return f"https://wa.me/?text={encoded_msg}"

def check_destination_traffic(location_name):
    """Fetch live traffic and compute full risk & alert payload for a specific destination."""
    coords = get_location_coordinates(location_name)
    if not coords:
        # Default coords for fallback
        coords = {"latitude": 21.1458, "longitude": 79.0882}
        
    traffic_res = get_live_traffic(coords["latitude"], coords["longitude"])
    weather_res = get_live_weather(coords["latitude"], coords["longitude"])
    
    ratio = traffic_res.get("traffic_ratio", 50)
    
    params = {
        "location": location_name,
        "vehicle_count": int(35 + (ratio * 1.4)),
        "occupancy": int(min(98, max(15, ratio * 1.1))),
        "queue_length": int(max(5, ratio * 0.85)),
        "lane_blockage": int(max(0, (ratio - 35) * 1.2)) if ratio > 35 else 0,
        "road_work": 20 if ratio > 65 else 0,
        "pedestrian_count": int(60 + ratio * 2.2),
        "turning_traffic": int(15 + ratio * 0.4),
        "emergency_vehicles": 1 if ratio > 75 else 0,
        "blocked_lanes": 1 if ratio > 65 else 0,
        "incident_severity": int(max(0, (ratio - 45) * 1.4)),
        "event_crowd_level": int(max(0, (ratio - 55) * 1.1)),
        "weather": weather_res.get("condition", "clear").lower()
    }
    
    risk_info = compute_explainable_risk(params)
    recs = generate_recommendations(params, risk_info, {})
    
    risk_score = risk_info.get("risk_score", int(ratio))
    traffic_level = "HEAVY" if risk_score > 75 else ("HIGH" if risk_score > 60 else ("MODERATE" if risk_score > 40 else "LOW"))
    speed_kmh = traffic_res.get("current_speed", int(max(10, 50 - (risk_score * 0.4))))
    
    return {
        "location": location_name,
        "risk_score": risk_score,
        "traffic_level": traffic_level,
        "speed_kmh": speed_kmh,
        "traffic_ratio": ratio,
        "causes": risk_info.get("top_risk_factors", ["Dense Traffic Flow"]),
        "recommendations": recs,
        "weather": weather_res.get("condition", "Clear"),
        "share_url": generate_whatsapp_share_link(location_name, risk_score, traffic_level, speed_kmh, risk_info.get("top_risk_factors", []), recs)
    }

def scan_and_notify_subscriptions():
    """Scan all saved subscriptions and send alerts if risk score exceeds threshold."""
    subscriptions = load_subscriptions()
    results = []
    
    for sub in subscriptions:
        phone = sub.get("phone_number")
        location = sub.get("target_location")
        api_key = sub.get("api_key", "")
        threshold = sub.get("risk_threshold", 65)
        
        status = check_destination_traffic(location)
        if status.get("risk_score", 0) >= threshold:
            alert_res = send_whatsapp_alert(
                phone_number=phone,
                api_key=api_key,
                location=location,
                risk_score=status["risk_score"],
                traffic_level=status["traffic_level"],
                speed_kmh=status["speed_kmh"],
                causes=status["causes"],
                recommendations=status["recommendations"]
            )
            results.append({
                "phone": phone,
                "location": location,
                "triggered": True,
                "risk_score": status["risk_score"],
                "alert_result": alert_res
            })
        else:
            results.append({
                "phone": phone,
                "location": location,
                "triggered": False,
                "risk_score": status["risk_score"],
                "message": f"Traffic risk ({status['risk_score']}%) below threshold ({threshold}%)"
            })
            
    return results

