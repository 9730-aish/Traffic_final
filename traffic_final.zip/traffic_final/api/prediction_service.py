﻿from datetime import datetime, timedelta


def predict_congestion(data):

    current_speed = float(
        data.get("current_speed", 0)
    )

    free_flow_speed = float(
        data.get("free_flow_speed", 50)
    )

    vehicle_count = float(
        data.get("vehicle_count", 0)
    )

    occupancy = float(
        data.get("occupancy", 0)
    )

    queue_length = float(
        data.get("queue_length", 0)
    )

    lane_blockage = float(
        data.get("lane_blockage", 0)
    )

    road_work = float(
        data.get("road_work", 0)
    )

    pedestrian_count = float(
        data.get("pedestrian_count", 0)
    )

    turning_traffic = float(
        data.get("turning_traffic", 0)
    )

    blocked_lanes = float(
        data.get("blocked_lanes", 0)
    )

    incident_severity = float(
        data.get("incident_severity", 0)
    )

    event_crowd_level = float(
        data.get("event_crowd_level", 0)
    )

    if free_flow_speed > 0:

        speed_congestion = (
            1 - (current_speed / free_flow_speed)
        ) * 100

    else:
        speed_congestion = 0

    speed_congestion = max(
        0,
        min(100, speed_congestion)
    )

    vehicle_factor = min(
        vehicle_count / 150,
        1
    ) * 100

    queue_factor = min(
        queue_length / 100,
        1
    ) * 100

    lane_factor = min(
        lane_blockage,
        100
    )

    road_work_factor = min(
        road_work,
        100
    )

    pedestrian_factor = min(
        pedestrian_count / 500,
        1
    ) * 100

    turning_factor = min(
        turning_traffic,
        100
    )

    blocked_lane_factor = min(
        blocked_lanes / 3,
        1
    ) * 100

    incident_factor = min(
        incident_severity,
        100
    )

    event_factor = min(
        event_crowd_level,
        100
    )

    current_score = (
        speed_congestion * 0.25
        + vehicle_factor * 0.15
        + occupancy * 0.10
        + queue_factor * 0.12
        + lane_factor * 0.08
        + road_work_factor * 0.06
        + pedestrian_factor * 0.04
        + turning_factor * 0.05
        + blocked_lane_factor * 0.05
        + incident_factor * 0.05
        + event_factor * 0.05
    )

    current_score = max(
        0,
        min(100, current_score)
    )

    pressure_factor = (
        queue_factor * 0.30
        + lane_factor * 0.20
        + incident_factor * 0.20
        + event_factor * 0.15
        + road_work_factor * 0.15
    )

    predicted_score = (
        current_score
        + (pressure_factor * 0.15)
    )

    predicted_score = max(
        0,
        min(100, predicted_score)
    )

    if predicted_score >= 75:
        predicted_level = "HEAVY"

    elif predicted_score >= 55:
        predicted_level = "HIGH"

    elif predicted_score >= 30:
        predicted_level = "MODERATE"

    else:
        predicted_level = "LOW"

    prediction_time = (
        datetime.now()
        + timedelta(minutes=15)
    ).strftime("%H:%M")

    return {
        "prediction_time": prediction_time,
        "predicted_score": round(
            predicted_score,
            2
        ),
        "predicted_level": predicted_level,
        "current_score": round(
            current_score,
            2
        ),
        "forecast_minutes": 15
    }
