﻿import os
import requests
from dotenv import load_dotenv

load_dotenv()

TOMTOM_API_KEY = os.getenv("TOMTOM_API_KEY")


def get_live_traffic(latitude, longitude):

    if not TOMTOM_API_KEY:
        return {
            "success": False,
            "error": "TomTom API key not found. Check your .env file."
        }

    url = (
        "https://api.tomtom.com/traffic/services/4/"
        "flowSegmentData/absolute/10/json"
    )

    params = {
        "point": f"{latitude},{longitude}",
        "unit": "KMPH",
        "key": TOMTOM_API_KEY
    }

    try:
        response = requests.get(
            url,
            params=params,
            timeout=10
        )

        if response.status_code != 200:
            return {
                "success": False,
                "error": f"TomTom API error: {response.status_code}"
            }

        data = response.json()

        flow_data = data.get(
            "flowSegmentData",
            {}
        )

        current_speed = flow_data.get(
            "currentSpeed",
            0
        )

        free_flow_speed = flow_data.get(
            "freeFlowSpeed",
            0
        )

        if free_flow_speed > 0:
            traffic_ratio = round(
                (1 - (current_speed / free_flow_speed)) * 100,
                2
            )
        else:
            traffic_ratio = 0

        if traffic_ratio >= 60:
            traffic_level = "HEAVY"
        elif traffic_ratio >= 35:
            traffic_level = "HIGH"
        elif traffic_ratio >= 15:
            traffic_level = "MODERATE"
        else:
            traffic_level = "LOW"

        confidence = flow_data.get(
            "confidence",
            0
        )

        return {
            "success": True,
            "current_speed": current_speed,
            "free_flow_speed": free_flow_speed,
            "traffic_ratio": traffic_ratio,
            "traffic_level": traffic_level,
            "confidence": round(confidence, 3),
            "latitude": latitude,
            "longitude": longitude
        }

    except requests.exceptions.Timeout:
        return {
            "success": False,
            "error": "TomTom API request timed out."
        }

    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "error": f"Network error: {str(e)}"
        }

    except Exception as e:
        return {
            "success": False,
            "error": f"Unexpected error: {str(e)}"
        }
