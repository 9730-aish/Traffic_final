def compute_explainable_risk(data):
    """
    Computes an Explainable Congestion & Dynamic Risk Score (0-100)
    with exact contribution percentages (Speed Reduction %, Incident %, Weather %, Queue/Trend %).
    """
    speed = float(data.get("current_speed", 40))
    free_flow = float(data.get("free_flow_speed", 50))
    incidents = float(data.get("incident_severity", 0))
    queue = float(data.get("queue_length", 0))
    occupancy = float(data.get("occupancy", 0))
    weather = str(data.get("weather", "clear")).lower()

    # 1. Speed reduction component (0 to 40 pts)
    speed_ratio = max(0.0, 1.0 - (speed / max(1.0, free_flow)))
    speed_pts = speed_ratio * 40.0

    # 2. Incident severity component (0 to 25 pts)
    incident_pts = min(25.0, (incidents / 100.0) * 25.0)

    # 3. Weather impact component (0 to 15 pts)
    weather_pts = 0.0
    if weather == "storm":
        weather_pts = 15.0
    elif weather == "rain":
        weather_pts = 10.0
    elif weather == "fog":
        weather_pts = 7.0

    # 4. Queue & occupancy component (0 to 20 pts)
    queue_pts = min(20.0, (queue / 100.0) * 12.0 + (occupancy / 100.0) * 8.0)

    total_score = min(100.0, max(0.0, round(speed_pts + incident_pts + weather_pts + queue_pts, 1)))

    # Calculate exact contribution percentage breakdown
    denom = max(1.0, total_score)
    speed_pct = round((speed_pts / denom) * 100.0)
    incident_pct = round((incident_pts / denom) * 100.0)
    weather_pct = round((weather_pts / denom) * 100.0)
    queue_pct = round((queue_pts / denom) * 100.0)

    # Normalize breakdown sum to 100% if total_score > 0
    if total_score > 0:
        total_pct = speed_pct + incident_pct + weather_pct + queue_pct
        if total_pct > 0:
            speed_pct = round((speed_pct / total_pct) * 100)
            incident_pct = round((incident_pct / total_pct) * 100)
            weather_pct = round((weather_pct / total_pct) * 100)
            queue_pct = 100 - (speed_pct + incident_pct + weather_pct)

    # Build natural language explanation sentence
    reasons = []
    if speed_ratio > 0.3:
        reasons.append(f"speed reduced by {round(speed_ratio * 100)}%")
    if incidents > 20:
        reasons.append(f"active traffic incident ({int(incidents)}% severity)")
    if weather_pts > 0:
        reasons.append(f"{weather} weather impact")
    if queue > 30:
        reasons.append(f"vehicle queue buildup ({int(queue)}m)")

    if reasons:
        explanation = f"Risk Score of {total_score}/100 driven by " + ", ".join(reasons) + "."
    else:
        explanation = f"Risk Score of {total_score}/100 indicates normal, uncongested flow."

    return {
        "risk_score": total_score,
        "risk_level": "CRITICAL" if total_score >= 80 else ("HIGH" if total_score >= 55 else ("MODERATE" if total_score >= 30 else "LOW")),
        "breakdown": {
            "speed_reduction_pct": speed_pct,
            "incident_severity_pct": incident_pct,
            "weather_impact_pct": weather_pct,
            "queue_density_pct": queue_pct
        },
        "explanation": explanation
    }
