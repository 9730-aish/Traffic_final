NAGPUR_METRO_STATIONS = {
    "Katol Road": {"nearest_station": "Kasturchand Park Station", "line": "Orange Line", "dist_km": 1.2},
    "Sadar": {"nearest_station": "Kasturchand Park Station", "line": "Orange Line", "dist_km": 0.8},
    "Sitabuldi": {"nearest_station": "Sitabuldi Interchange Station", "line": "Orange & Aqua Line Junction", "dist_km": 0.1},
    "Wardha Road": {"nearest_station": "Airport Station", "line": "Orange Line", "dist_km": 0.5},
    "Dharampeth": {"nearest_station": "Institute of Engineers Station", "line": "Aqua Line", "dist_km": 0.9},
    "Central Avenue (CA Road)": {"nearest_station": "Dosar Vaisya Square Station", "line": "Aqua Line", "dist_km": 0.6},
    "Kamptee Road": {"nearest_station": "Automotive Square Station", "line": "Orange Line", "dist_km": 1.1},
    "Airport Road": {"nearest_station": "Airport Station", "line": "Orange Line", "dist_km": 0.4},
    "MIHAN SEZ": {"nearest_station": "Khapri Station", "line": "Orange Line", "dist_km": 1.5},
    "Medical Square": {"nearest_station": "Medical Square Station", "line": "Aqua Line", "dist_km": 0.3},
    "Manewada": {"nearest_station": "Congress Nagar Station", "line": "Orange Line", "dist_km": 2.1},
    "Civil Lines": {"nearest_station": "Zero Mile Freedom Park Station", "line": "Orange Line", "dist_km": 0.7},
    "Amravati Road": {"nearest_station": "Subhash Nagar Station", "line": "Aqua Line", "dist_km": 1.4},
    "Koradi Road": {"nearest_station": "Automotive Square Station", "line": "Orange Line", "dist_km": 2.8},
    "Pratap Nagar": {"nearest_station": "Subhash Nagar Station", "line": "Aqua Line", "dist_km": 1.0},
    "Khamla Road": {"nearest_station": "Ajni Square Station", "line": "Orange Line", "dist_km": 0.9},
    "Trimurti Nagar": {"nearest_station": "Subhash Nagar Station", "line": "Aqua Line", "dist_km": 1.2},
    "Pardi Square": {"nearest_station": "Prajapati Nagar Station", "line": "Aqua Line", "dist_km": 0.8},
    "Kalamna / Bhandara Road": {"nearest_station": "Prajapati Nagar Station", "line": "Aqua Line", "dist_km": 1.5},
    "Mahal": {"nearest_station": "Cotton Market Station", "line": "Aqua Line", "dist_km": 0.9},
    "Manish Nagar": {"nearest_station": "Airport South Station", "line": "Orange Line", "dist_km": 1.1},
    "Ring Road": {"nearest_station": "Chhatrapati Square Station", "line": "Orange Line", "dist_km": 0.7}
}

def calculate_metro_switch(origin, destination, traffic_ratio=75):
    """
    Calculates Multi-Modal Transit Switch recommendations for Nagpur Metro.
    Compares road travel time & fuel costs against metro transit.
    """
    origin_info = NAGPUR_METRO_STATIONS.get(origin, {"nearest_station": "Sitabuldi Interchange", "line": "Orange Line", "dist_km": 1.0})
    dest_info = NAGPUR_METRO_STATIONS.get(destination, {"nearest_station": "Medical Square Station", "line": "Aqua Line", "dist_km": 0.8})

    # Road travel calculation
    base_road_time = 18.0
    delay_multiplier = 1.0 + (traffic_ratio / 40.0)
    road_time_mins = round(base_road_time * delay_multiplier, 1)
    road_fuel_cost = int(80 + (traffic_ratio * 1.2))

    # Metro travel calculation
    metro_walk_origin_mins = round(origin_info["dist_km"] * 6, 1)
    metro_ride_mins = 11.0
    metro_walk_dest_mins = round(dest_info["dist_km"] * 6, 1)
    metro_total_mins = round(metro_walk_origin_mins + metro_ride_mins + metro_walk_dest_mins, 1)
    metro_ticket_cost = 20

    time_saved = round(max(0, road_time_mins - metro_total_mins), 1)
    money_saved = max(0, road_fuel_cost - metro_ticket_cost)

    is_recommended = traffic_ratio >= 45 or time_saved > 5.0

    if is_recommended:
        status_text = f"🚇 METRO HIGHLY RECOMMENDED (Save {time_saved} Mins & ₹{money_saved})"
        recommendation_msg = (
            f"Traffic congestion at {origin} is high ({traffic_ratio}% delay). "
            f"Switching to Nagpur Metro saves ~{time_saved} minutes and ₹{money_saved} in fuel!"
        )
    else:
        status_text = f"🚗 ROAD FLOW ACCEPTABLE (Metro Available as Alternative)"
        recommendation_msg = (
            f"Road traffic between {origin} and {destination} is moving steadily. "
            f"Nagpur Metro is available as a 0-emissions alternative."
        )

    commute_steps = [
        f"1. Reach nearest station: '{origin_info['nearest_station']}' ({origin_info['dist_km']} km from {origin})",
        f"2. Board Nagpur Metro [{origin_info['line']}] ➔ Sitabuldi Interchange",
        f"3. De-board at '{dest_info['nearest_station']}' ({dest_info['line']})",
        f"4. Short 3-min walk/E-Rickshaw to {destination}"
    ]

    return {
        "success": True,
        "origin": origin,
        "destination": destination,
        "traffic_ratio": traffic_ratio,
        "is_recommended": is_recommended,
        "status_text": status_text,
        "recommendation_msg": recommendation_msg,
        "road_travel": {
            "time_mins": road_time_mins,
            "cost_inr": road_fuel_cost,
            "stress_level": "HIGH" if traffic_ratio >= 60 else "MODERATE",
            "co2_emissions": f"{round(road_time_mins * 0.12, 2)} kg CO2"
        },
        "metro_travel": {
            "origin_station": origin_info["nearest_station"],
            "dest_station": dest_info["nearest_station"],
            "line": origin_info["line"],
            "time_mins": metro_total_mins,
            "cost_inr": metro_ticket_cost,
            "stress_level": "ZERO (AC & Traffic Free)",
            "co2_emissions": "0.00 kg CO2 (100% Green)"
        },
        "time_saved_mins": time_saved,
        "money_saved_inr": money_saved,
        "commute_steps": commute_steps
    }
