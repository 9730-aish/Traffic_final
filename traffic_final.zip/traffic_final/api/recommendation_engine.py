def generate_recommendations(data, risk_data, propagation_data):
    """
    Generates actionable alternate-route recommendations and traffic control actions
    based on risk score, cause verification, and road propagation analysis.
    """
    location = data.get("location", "Current Junction")
    risk_score = risk_data.get("risk_score", 0)
    connected = propagation_data.get("connected_junctions", ["Ring Road"])
    
    alternate_route = connected[0] if connected else "Ring Road Bypass"
    if len(connected) > 1:
        secondary_route = connected[1]
    else:
        secondary_route = "Outer Bypass"
    actions = []
    if risk_score >= 75:
        actions.append(f"🚨 REROUTE ADVISORY: Divert heavy vehicle traffic away from {location} via {alternate_route}.")
        actions.append("🚥 SIGNAL CONTROL: Increase green light interval by +25s on primary inflow direction.")
        actions.append("👮 TRAFFIC WARDEN: Deploy manual traffic control team at bottleneck intersection.")
    elif risk_score >= 45:
        actions.append(f"⚠️ CONGESTION WARNING: Recommend light traffic divert toward {alternate_route} or {secondary_route}.")
        actions.append("🚥 SIGNAL CONTROL: Maintain dynamic green time extension of +10s.")
    else:
        actions.append(f"🟢 CLEAR FLOW: Optimal speed maintained at {location}. No rerouting required.")
    return {
        "primary_recommendation": actions[0] if actions else "Maintain current traffic signal timing.",
        "action_list": actions,
        "recommended_alternate_route": alternate_route,
        "secondary_bypass": secondary_route,
        "operator_decision_support": f"Priority Level: {'HIGH' if risk_score >= 60 else 'NORMAL'} - Divert flow to {alternate_route} to prevent corridor gridlock."
    }