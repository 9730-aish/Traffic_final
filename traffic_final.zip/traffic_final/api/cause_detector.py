﻿def detect_traffic_causes(data):

    causes = []

    queue_length = float(data.get("queue_length", 0))
    lane_blockage = float(data.get("lane_blockage", 0))
    road_work = float(data.get("road_work", 0))
    pedestrian_count = float(data.get("pedestrian_count", 0))
    turning_traffic = float(data.get("turning_traffic", 0))
    emergency_vehicles = float(data.get("emergency_vehicles", 0))
    blocked_lanes = float(data.get("blocked_lanes", 0))
    incident_severity = float(data.get("incident_severity", 0))
    event_crowd_level = float(data.get("event_crowd_level", 0))

    if queue_length >= 50:
        causes.append({
            "cause": "Long Vehicle Queue",
            "severity": "HIGH",
            "message": "A long vehicle queue is contributing significantly to congestion."
        })
    elif queue_length >= 25:
        causes.append({
            "cause": "Growing Vehicle Queue",
            "severity": "MEDIUM",
            "message": "Vehicle queue is increasing and may slow traffic."
        })

    if lane_blockage >= 60:
        causes.append({
            "cause": "Major Lane Blockage",
            "severity": "HIGH",
            "message": "A large portion of road capacity is blocked."
        })
    elif lane_blockage >= 30:
        causes.append({
            "cause": "Partial Lane Blockage",
            "severity": "MEDIUM",
            "message": "Blocked road space is reducing traffic flow."
        })

    if road_work >= 70:
        causes.append({
            "cause": "Major Road Construction",
            "severity": "HIGH",
            "message": "Major road work is reducing available road capacity."
        })
    elif road_work >= 30:
        causes.append({
            "cause": "Road Work",
            "severity": "MEDIUM",
            "message": "Construction activity is affecting traffic movement."
        })

    if pedestrian_count >= 300:
        causes.append({
            "cause": "High Pedestrian Activity",
            "severity": "HIGH",
            "message": "Heavy pedestrian movement may be slowing vehicles."
        })
    elif pedestrian_count >= 150:
        causes.append({
            "cause": "Moderate Pedestrian Activity",
            "severity": "MEDIUM",
            "message": "Pedestrian movement is affecting traffic flow."
        })

    if turning_traffic >= 60:
        causes.append({
            "cause": "High Turning Traffic",
            "severity": "HIGH",
            "message": "Frequent turning movements are creating junction conflicts."
        })
    elif turning_traffic >= 30:
        causes.append({
            "cause": "Moderate Turning Traffic",
            "severity": "MEDIUM",
            "message": "Turning vehicles are reducing junction efficiency."
        })

    if emergency_vehicles >= 2:
        causes.append({
            "cause": "Emergency Vehicle Movement",
            "severity": "HIGH",
            "message": "Emergency vehicle priority may temporarily affect normal traffic flow."
        })

    if blocked_lanes >= 2:
        causes.append({
            "cause": "Multiple Blocked Lanes",
            "severity": "HIGH",
            "message": "Multiple lanes are unavailable for normal traffic."
        })
    elif blocked_lanes >= 1:
        causes.append({
            "cause": "Blocked Lane",
            "severity": "MEDIUM",
            "message": "One lane is unavailable, reducing road capacity."
        })

    if incident_severity >= 70:
        causes.append({
            "cause": "Major Traffic Incident",
            "severity": "HIGH",
            "message": "A serious traffic incident is likely affecting vehicle movement."
        })
    elif incident_severity >= 30:
        causes.append({
            "cause": "Traffic Incident",
            "severity": "MEDIUM",
            "message": "An incident may be contributing to congestion."
        })

    if event_crowd_level >= 70:
        causes.append({
            "cause": "Large Event Crowd",
            "severity": "HIGH",
            "message": "High crowd activity near the road may be increasing traffic demand."
        })
    elif event_crowd_level >= 30:
        causes.append({
            "cause": "Event Crowd",
            "severity": "MEDIUM",
            "message": "Nearby event activity may be increasing traffic volume."
        })

    if not causes:
        causes.append({
            "cause": "Normal Traffic Conditions",
            "severity": "LOW",
            "message": "No major congestion-causing factor was detected."
        })

    high_count = sum(
        1 for cause in causes
        if cause["severity"] == "HIGH"
    )

    medium_count = sum(
        1 for cause in causes
        if cause["severity"] == "MEDIUM"
    )

    cause_score = min(
        100,
        (high_count * 25) + (medium_count * 12)
    )

    return {
        "causes": causes,
        "cause_count": len(causes),
        "cause_score": cause_score
    }
