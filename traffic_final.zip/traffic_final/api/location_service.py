try:
    from config.settings import NAGPUR_LOCATIONS
except ImportError:
    NAGPUR_LOCATIONS = {
        "Sitabuldi": {"latitude": 21.1458, "longitude": 79.0882},
        "Wardha Road": {"latitude": 21.1120, "longitude": 79.0720},
        "Hingna Road": {"latitude": 21.1070, "longitude": 78.9920},
        "Kamptee Road": {"latitude": 21.1800, "longitude": 79.1100},
        "Katol Road": {"latitude": 21.1785, "longitude": 79.0520},
        "Amravati Road": {"latitude": 21.1470, "longitude": 79.0430},
        "Central Avenue (CA Road)": {"latitude": 21.1480, "longitude": 79.1120},
        "Koradi Road": {"latitude": 21.2200, "longitude": 79.0850},
        "Kalamna / Bhandara Road": {"latitude": 21.1620, "longitude": 79.1450},
        "MIHAN SEZ": {"latitude": 21.0350, "longitude": 79.0480},
        "Pratap Nagar": {"latitude": 21.1200, "longitude": 79.0500},
        "Khamla Road": {"latitude": 21.1150, "longitude": 79.0620},
        "Trimurti Nagar": {"latitude": 21.1100, "longitude": 79.0350},
        "Pardi Square": {"latitude": 21.1550, "longitude": 79.1380},
        "Manewada": {"latitude": 21.1050, "longitude": 79.0900},
        "Sadar": {"latitude": 21.1650, "longitude": 79.0880},
        "Civil Lines": {"latitude": 21.1550, "longitude": 79.0720},
        "Dharampeth": {"latitude": 21.1450, "longitude": 79.0670},
        "Medical Square": {"latitude": 21.1250, "longitude": 79.0950},
        "Manish Nagar": {"latitude": 21.1055, "longitude": 79.0780},
        "Airport Road": {"latitude": 21.1530, "longitude": 79.0830},
        "Mahal": {"latitude": 21.1400, "longitude": 79.1050}
    }


def get_locations():
    return NAGPUR_LOCATIONS


def get_location_coordinates(location_name):

    location = NAGPUR_LOCATIONS.get(
        location_name
    )

    if not location:
        return None

    return location
