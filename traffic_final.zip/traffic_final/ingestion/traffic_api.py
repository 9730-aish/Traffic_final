import os
import requests
from dotenv import load_dotenv

from config.settings import NAGPUR_LOCATIONS


# Load environment variables
load_dotenv()


TOMTOM_API_KEY = os.getenv("TOMTOM_API_KEY")


def get_location_coordinates(location_name):
    """
    Get latitude and longitude for selected Nagpur location.
    """

    location = NAGPUR_LOCATIONS.get(location_name)

    if not location:
        return None

    return {
        "latitude": location["latitude"],
        "longitude": location["longitude"]
    }


def get_live_traffic(location_name):
    """
    Fetch live traffic information from TomTom API.
    """

    coordinates = get_location_coordinates(location_name)

    if coordinates is None:
        return {
            "success": False,
            "error": "Location not found"
        }

    if not TOMTOM_API_KEY:
        return {
            "success": False,
            "error": "TomTom API key not configured"
        }

    latitude = coordinates["latitude"]
    longitude = coordinates["longitude"]

    url = (
        "https://api.tomtom.com/traffic/services/4/flowSegmentData/"
        "absolute/10/json"
    )

    params = {
        "key": TOMTOM_API_KEY,
        "point": f"{latitude},{longitude}"
    }

    try:

        response = requests.get(
            url,
            params=params,
            timeout=10
        )

        response.raise_for_status()

        data = response.json()

        flow_data = data.get("flowSegmentData", {})

        current_speed = flow_data.get("currentSpeed", 0)
        free_flow_speed = flow_data.get("freeFlowSpeed", 0)

        if free_flow_speed > 0:

            traffic_ratio = round(
                (1 - (current_speed / free_flow_speed)) * 100,
                2
            )

        else:
            traffic_ratio = 0

        if traffic_ratio < 20:
            traffic_level = "LOW"

        elif traffic_ratio < 40:
            traffic_level = "NORMAL"

        elif traffic_ratio < 60:
            traffic_level = "MODERATE"

        elif traffic_ratio < 80:
            traffic_level = "HIGH"

        else:
            traffic_level = "HEAVY"

        return {
            "success": True,
            "location": location_name,
            "latitude": latitude,
            "longitude": longitude,
            "current_speed": current_speed,
            "free_flow_speed": free_flow_speed,
            "traffic_ratio": traffic_ratio,
            "traffic_level": traffic_level,
            "confidence": flow_data.get("confidence", 0)
        }

    except requests.exceptions.RequestException as error:

        return {
            "success": False,
            "error": str(error)
        }

    except Exception as error:

        return {
            "success": False,
            "error": str(error)
        }