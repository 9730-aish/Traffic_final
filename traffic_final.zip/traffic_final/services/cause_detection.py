# ============================================================
# TrafficTwin AI - Traffic Cause Detection Engine
# ============================================================

from preprocessing.traffic_features import create_traffic_features


def detect_traffic_causes(data):
    """
    Detects the main reasons behind traffic congestion.
    """

    features = create_traffic_features(data)

    causes = []

    # --------------------------------------------------------
    # Vehicle pressure
    # --------------------------------------------------------

    if features["vehicle_pressure"] >= 80:
        causes.append({
            "cause": "High Vehicle Volume",
            "impact": "HIGH",
            "score": features["vehicle_pressure"]
        })

    elif features["vehicle_pressure"] >= 60:
        causes.append({
            "cause": "Increasing Vehicle Volume",
            "impact": "MEDIUM",
            "score": features["vehicle_pressure"]
        })


    # --------------------------------------------------------
    # Speed loss
    # --------------------------------------------------------

    if features["speed_loss"] >= 60:
        causes.append({
            "cause": "Severe Speed Reduction",
            "impact": "HIGH",
            "score": features["speed_loss"]
        })

    elif features["speed_loss"] >= 35:
        causes.append({
            "cause": "Reduced Traffic Speed",
            "impact": "MEDIUM",
            "score": features["speed_loss"]
        })


    # --------------------------------------------------------
    # Queue
    # --------------------------------------------------------

    if features["queue_pressure"] >= 70:
        causes.append({
            "cause": "Long Vehicle Queue",
            "impact": "HIGH",
            "score": features["queue_pressure"]
        })

    elif features["queue_pressure"] >= 40:
        causes.append({
            "cause": "Growing Vehicle Queue",
            "impact": "MEDIUM",
            "score": features["queue_pressure"]
        })


    # --------------------------------------------------------
    # Lane blockage
    # --------------------------------------------------------

    if features["lane_blockage_pressure"] >= 50:
        causes.append({
            "cause": "Lane Blockage",
            "impact": "HIGH",
            "score": features["lane_blockage_pressure"]
        })


    # --------------------------------------------------------
    # Pedestrian pressure
    # --------------------------------------------------------

    if features["pedestrian_pressure"] >= 60:
        causes.append({
            "cause": "Heavy Pedestrian Activity",
            "impact": "HIGH",
            "score": features["pedestrian_pressure"]
        })


    # --------------------------------------------------------
    # Turning traffic
    # --------------------------------------------------------

    if features["turning_pressure"] >= 60:
        causes.append({
            "cause": "High Turning Traffic",
            "impact": "MEDIUM",
            "score": features["turning_pressure"]
        })


    # --------------------------------------------------------
    # Road incident
    # --------------------------------------------------------

    if features["incident_pressure"] >= 60:
        causes.append({
            "cause": "Traffic Incident",
            "impact": "HIGH",
            "score": features["incident_pressure"]
        })

    elif features["incident_pressure"] >= 25:
        causes.append({
            "cause": "Minor Traffic Incident",
            "impact": "MEDIUM",
            "score": features["incident_pressure"]
        })


    # --------------------------------------------------------
    # Weather
    # --------------------------------------------------------

    if features["weather_pressure"] >= 60:
        causes.append({
            "cause": "Adverse Weather",
            "impact": "HIGH",
            "score": features["weather_pressure"]
        })

    elif features["weather_pressure"] >= 30:
        causes.append({
            "cause": "Weather Affecting Traffic",
            "impact": "MEDIUM",
            "score": features["weather_pressure"]
        })


    # --------------------------------------------------------
    # Event crowd
    # --------------------------------------------------------

    if features["event_pressure"] >= 70:
        causes.append({
            "cause": "High Event / Crowd Activity",
            "impact": "HIGH",
            "score": features["event_pressure"]
        })

    elif features["event_pressure"] >= 40:
        causes.append({
            "cause": "Moderate Event / Crowd Activity",
            "impact": "MEDIUM",
            "score": features["event_pressure"]
        })


    # --------------------------------------------------------
    # Sort causes by impact score
    # --------------------------------------------------------

    causes.sort(
        key=lambda x: x["score"],
        reverse=True
    )


    # --------------------------------------------------------
    # Main cause
    # --------------------------------------------------------

    if causes:

        main_cause = causes[0]["cause"]

    else:

        main_cause = "No major congestion cause detected"


    return {
        "main_cause": main_cause,
        "causes": causes,
        "total_causes": len(causes),
        "features": features
    }