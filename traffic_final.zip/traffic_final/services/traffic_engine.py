# ============================================================
# TrafficTwin AI - Central Traffic Intelligence Engine
# ============================================================

from services.cause_detection import detect_traffic_causes
from services.signal_optimizer import optimize_signal
from services.prediction import predict_next_15_minutes


def analyze_traffic(data):
    """
    Combines all TrafficTwin AI intelligence modules.
    """

    # --------------------------------------------------------
    # Traffic Cause Detection
    # --------------------------------------------------------

    cause_result = detect_traffic_causes(data)

    # --------------------------------------------------------
    # Future Traffic Prediction
    # --------------------------------------------------------

    prediction_result = predict_next_15_minutes(data)

    # --------------------------------------------------------
    # Smart Signal Optimization
    # --------------------------------------------------------

    signal_result = optimize_signal(data)

    # --------------------------------------------------------
    # Final AI result
    # --------------------------------------------------------

    return {
        "cause_detection": cause_result,

        "prediction": prediction_result,

        "signal_optimization": signal_result,

        "summary": {
            "main_cause":
                cause_result["main_cause"],

            "predicted_level":
                prediction_result["predicted_level"],

            "prediction_trend":
                prediction_result["trend"],

            "traffic_pressure":
                signal_result["traffic_pressure"],

            "recommended_action":
                signal_result["signal_action"]
        }
    }