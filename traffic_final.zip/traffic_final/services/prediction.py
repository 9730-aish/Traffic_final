# ============================================================
# TrafficTwin AI - Future Traffic Prediction
# ============================================================

from datetime import datetime, timedelta


def predict_next_15_minutes(current_data):
    """
    Estimates traffic condition for the next 15 minutes
    using current traffic pressure and major influencing factors.
    """

    vehicle_count = current_data.get("vehicle_count", 0)
    road_capacity = current_data.get("road_capacity", 1)

    queue_length = current_data.get("queue_length", 0)
    blocked_lanes = current_data.get("blocked_lanes", 0)
    lane_count = current_data.get("lane_count", 1)

    current_speed = current_data.get("current_speed", 0)
    free_flow_speed = current_data.get(
        "free_flow_speed",
        current_speed
    )

    # --------------------------------------------------------
    # Vehicle pressure
    # --------------------------------------------------------

    if road_capacity > 0:
        vehicle_pressure = (
            vehicle_count / road_capacity
        ) * 100
    else:
        vehicle_pressure = 0

    # --------------------------------------------------------
    # Speed loss
    # --------------------------------------------------------

    if free_flow_speed > 0:
        speed_loss = (
            (free_flow_speed - current_speed)
            / free_flow_speed
        ) * 100
    else:
        speed_loss = 0

    # --------------------------------------------------------
    # Queue pressure
    # --------------------------------------------------------

    queue_pressure = (
        queue_length / 100
    ) * 100

    # --------------------------------------------------------
    # Lane blockage
    # --------------------------------------------------------

    if lane_count > 0:
        blockage_pressure = (
            blocked_lanes / lane_count
        ) * 100
    else:
        blockage_pressure = 0

    # Keep values between 0 and 100

    vehicle_pressure = min(
        max(vehicle_pressure, 0),
        100
    )

    speed_loss = min(
        max(speed_loss, 0),
        100
    )

    queue_pressure = min(
        max(queue_pressure, 0),
        100
    )

    blockage_pressure = min(
        max(blockage_pressure, 0),
        100
    )

    # --------------------------------------------------------
    # Future congestion score
    # --------------------------------------------------------

    future_score = (
        vehicle_pressure * 0.30
        + speed_loss * 0.25
        + queue_pressure * 0.30
        + blockage_pressure * 0.15
    )

    future_score = round(
        min(max(future_score, 0), 100),
        2
    )

    # --------------------------------------------------------
    # Predict traffic level
    # --------------------------------------------------------

    if future_score < 20:
        predicted_level = "LOW"

    elif future_score < 40:
        predicted_level = "NORMAL"

    elif future_score < 60:
        predicted_level = "MODERATE"

    elif future_score < 80:
        predicted_level = "HIGH"

    else:
        predicted_level = "HEAVY"

    # --------------------------------------------------------
    # Prediction time
    # --------------------------------------------------------

    prediction_time = (
        datetime.now()
        + timedelta(minutes=15)
    )

    # --------------------------------------------------------
    # Trend
    # --------------------------------------------------------

    if future_score >= 65:
        trend = "INCREASING"

    elif future_score <= 30:
        trend = "DECREASING"

    else:
        trend = "STABLE"

    return {
        "prediction_time": prediction_time.strftime(
            "%H:%M"
        ),
        "predicted_level": predicted_level,
        "predicted_score": future_score,
        "trend": trend
    }