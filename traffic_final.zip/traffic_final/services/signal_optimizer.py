# ============================================================
# TrafficTwin AI - Smart Signal Optimization Engine
# ============================================================

from config.settings import MIN_GREEN_TIME, MAX_GREEN_TIME


def optimize_signal(data):
    """
    Calculates recommended traffic-signal timing
    based on multiple traffic conditions.
    """

    vehicle_count = data.get("vehicle_count", 0)
    road_capacity = data.get("road_capacity", 1)

    queue_length = data.get("queue_length", 0)
    blocked_lanes = data.get("blocked_lanes", 0)
    lane_count = data.get("lane_count", 1)

    pedestrian_count = data.get("pedestrian_count", 0)
    emergency_vehicles = data.get("emergency_vehicles", 0)

    current_green_time = data.get(
        "current_green_time",
        60
    )

    # --------------------------------------------------------
    # Vehicle pressure
    # --------------------------------------------------------

    if road_capacity > 0:
        vehicle_pressure = (
            vehicle_count / road_capacity
        ) * 100
    else:
        vehicle_pressure = 0

    vehicle_pressure = min(
        max(vehicle_pressure, 0),
        100
    )

    # --------------------------------------------------------
    # Queue pressure
    # --------------------------------------------------------

    queue_pressure = min(
        (queue_length / 100) * 100,
        100
    )

    # --------------------------------------------------------
    # Lane blockage pressure
    # --------------------------------------------------------

    if lane_count > 0:
        blockage_pressure = (
            blocked_lanes / lane_count
        ) * 100
    else:
        blockage_pressure = 0

    blockage_pressure = min(
        max(blockage_pressure, 0),
        100
    )

    # --------------------------------------------------------
    # Pedestrian pressure
    # --------------------------------------------------------

    pedestrian_pressure = min(
        (pedestrian_count / 200) * 100,
        100
    )

    # --------------------------------------------------------
    # Emergency vehicle priority
    # --------------------------------------------------------

    emergency_priority = emergency_vehicles > 0

    # --------------------------------------------------------
    # Overall traffic pressure
    # --------------------------------------------------------

    traffic_pressure = (
        vehicle_pressure * 0.35
        + queue_pressure * 0.30
        + blockage_pressure * 0.20
        + pedestrian_pressure * 0.15
    )

    traffic_pressure = round(
        min(max(traffic_pressure, 0), 100),
        2
    )

    # --------------------------------------------------------
    # Emergency vehicle case
    # --------------------------------------------------------

    if emergency_priority:

        recommended_green = MAX_GREEN_TIME

        recommended_red = 30

        signal_action = (
            "Emergency Priority - "
            "Extend Green Signal"
        )

        signal_change = (
            recommended_green
            - current_green_time
        )

    # --------------------------------------------------------
    # Very high traffic
    # --------------------------------------------------------

    elif traffic_pressure >= 75:

        recommended_green = min(
            current_green_time + 30,
            MAX_GREEN_TIME
        )

        recommended_red = 30

        signal_action = (
            "Increase Green Time"
        )

        signal_change = (
            recommended_green
            - current_green_time
        )

    # --------------------------------------------------------
    # High traffic
    # --------------------------------------------------------

    elif traffic_pressure >= 55:

        recommended_green = min(
            current_green_time + 15,
            MAX_GREEN_TIME
        )

        recommended_red = 40

        signal_action = (
            "Moderately Extend Green Time"
        )

        signal_change = (
            recommended_green
            - current_green_time
        )

    # --------------------------------------------------------
    # Normal traffic
    # --------------------------------------------------------

    elif traffic_pressure >= 30:

        recommended_green = current_green_time

        recommended_red = 50

        signal_action = (
            "Maintain Current Signal Timing"
        )

        signal_change = 0

    # --------------------------------------------------------
    # Low traffic
    # --------------------------------------------------------

    else:

        recommended_green = max(
            current_green_time - 15,
            MIN_GREEN_TIME
        )

        recommended_red = 60

        signal_action = (
            "Reduce Green Time"
        )

        signal_change = (
            recommended_green
            - current_green_time
        )

    return {
        "traffic_pressure": traffic_pressure,
        "recommended_green_time": recommended_green,
        "recommended_red_time": recommended_red,
        "signal_action": signal_action,
        "signal_change": signal_change,
        "emergency_priority": emergency_priority
    }