# ============================================================
# TrafficTwin AI - Traffic Prediction Model
# ============================================================

import os
import joblib
import pandas as pd

from sklearn.ensemble import RandomForestClassifier


# ------------------------------------------------------------
# Model location
# ------------------------------------------------------------

MODEL_FOLDER = os.path.join(
    os.path.dirname(__file__),
    "saved_models"
)

MODEL_PATH = os.path.join(
    MODEL_FOLDER,
    "traffic_model.pkl"
)


# ------------------------------------------------------------
# Model features
# ------------------------------------------------------------

MODEL_FEATURES = [
    "CarCount",
    "BikeCount",
    "BusCount",
    "TruckCount",
    "Total"
]


# ------------------------------------------------------------
# Train model
# ------------------------------------------------------------

def train_traffic_model(csv_path):
    """
    Train Random Forest model using traffic dataset.
    """

    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"Dataset not found: {csv_path}"
        )

    data = pd.read_csv(csv_path)

    required_columns = MODEL_FEATURES + [
        "Traffic Situation"
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in data.columns
    ]

    if missing_columns:
        raise ValueError(
            f"Missing columns: {missing_columns}"
        )

    X = data[MODEL_FEATURES]

    y = data["Traffic Situation"]

    model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        class_weight="balanced"
    )

    model.fit(X, y)

    os.makedirs(
        MODEL_FOLDER,
        exist_ok=True
    )

    joblib.dump(
        model,
        MODEL_PATH
    )

    return model


# ------------------------------------------------------------
# Load saved model
# ------------------------------------------------------------

def load_traffic_model():
    """
    Load previously trained traffic model.
    """

    if not os.path.exists(MODEL_PATH):
        return None

    return joblib.load(MODEL_PATH)


# ------------------------------------------------------------
# Predict traffic situation
# ------------------------------------------------------------

def predict_traffic(
    car_count,
    bike_count,
    bus_count,
    truck_count,
    total
):
    """
    Predict traffic situation.
    """

    model = load_traffic_model()

    if model is None:
        return {
            "success": False,
            "error": "Traffic model is not trained yet."
        }

    input_data = pd.DataFrame(
        [[
            car_count,
            bike_count,
            bus_count,
            truck_count,
            total
        ]],
        columns=MODEL_FEATURES
    )

    prediction = model.predict(
        input_data
    )[0]

    confidence = None

    if hasattr(model, "predict_proba"):

        probabilities = model.predict_proba(
            input_data
        )[0]

        confidence = round(
            float(max(probabilities)) * 100,
            2
        )

    return {
        "success": True,
        "traffic_situation": str(prediction),
        "confidence": confidence
    }