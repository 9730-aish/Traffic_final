const CACHE_NAME = 'traffictwin-v2.0';
const ASSETS_TO_CACHE = [
  '/',
  '/dashboard',
  '/static/manifest.json',
  'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
];

// Install Event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE);
    }).then(() => self.skipWaiting())
  );
});

// Activate Event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event (Network First for Live APIs, Cache Fallback for Assets)
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/live_traffic') || 
      event.request.url.includes('/analyze') || 
      event.request.url.includes('/api/')) {
    // Live API Calls -> Network Only
    event.respondWith(fetch(event.request));
  } else {
    // Static Assets -> Network first, fallback to Cache
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
  }
});
