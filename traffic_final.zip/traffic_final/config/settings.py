# ============================================================
# TrafficTwin AI - Central Project Settings
# AI-Powered Urban Traffic Intelligence System
# ============================================================

PROJECT_NAME = "TrafficTwin AI"
PROJECT_VERSION = "2.0"

# ------------------------------------------------------------
# CITY
# ------------------------------------------------------------

CITY = "Nagpur"
COUNTRY = "India"


# ------------------------------------------------------------
# NAGPUR TRAFFIC MONITORING LOCATIONS
# ------------------------------------------------------------

NAGPUR_LOCATIONS = {
    "Sitabuldi": {
        "latitude": 21.1458,
        "longitude": 79.0882
    },

    "Wardha Road": {
        "latitude": 21.1120,
        "longitude": 79.0720
    },

    "Hingna Road": {
        "latitude": 21.1070,
        "longitude": 78.9920
    },

    "Kamptee Road": {
        "latitude": 21.1800,
        "longitude": 79.1100
    },

    "Katol Road": {
        "latitude": 21.1785,
        "longitude": 79.0520
    },

    "Amravati Road": {
        "latitude": 21.1470,
        "longitude": 79.0430
    },

    "Central Avenue (CA Road)": {
        "latitude": 21.1480,
        "longitude": 79.1120
    },

    "Koradi Road": {
        "latitude": 21.2200,
        "longitude": 79.0850
    },

    "Kalamna / Bhandara Road": {
        "latitude": 21.1620,
        "longitude": 79.1450
    },

    "MIHAN SEZ": {
        "latitude": 21.0350,
        "longitude": 79.0480
    },

    "Pratap Nagar": {
        "latitude": 21.1200,
        "longitude": 79.0500
    },

    "Khamla Road": {
        "latitude": 21.1150,
        "longitude": 79.0620
    },

    "Trimurti Nagar": {
        "latitude": 21.1100,
        "longitude": 79.0350
    },

    "Pardi Square": {
        "latitude": 21.1550,
        "longitude": 79.1380
    },

    "Manewada": {
        "latitude": 21.1050,
        "longitude": 79.0900
    },

    "Sadar": {
        "latitude": 21.1650,
        "longitude": 79.0880
    },

    "Civil Lines": {
        "latitude": 21.1550,
        "longitude": 79.0720
    },

    "Dharampeth": {
        "latitude": 21.1450,
        "longitude": 79.0670
    },

    "Medical Square": {
        "latitude": 21.1250,
        "longitude": 79.0950
    },

    "Manish Nagar": {
        "latitude": 21.1055,
        "longitude": 79.0780
    },

    "Airport Road": {
        "latitude": 21.1530,
        "longitude": 79.0830
    },

    "Mahal": {
        "latitude": 21.1400,
        "longitude": 79.1050
    }
}


# ------------------------------------------------------------
# DEFAULT LOCATION
# ------------------------------------------------------------

DEFAULT_LOCATION = "Sitabuldi"


# ------------------------------------------------------------
# TRAFFIC PREDICTION
# ------------------------------------------------------------

PREDICTION_INTERVAL = 15


# ------------------------------------------------------------
# TRAFFIC LEVELS
# ------------------------------------------------------------

TRAFFIC_LEVELS = [
    "LOW",
    "NORMAL",
    "MODERATE",
    "HIGH",
    "HEAVY"
]


# ------------------------------------------------------------
# EXISTING TRAFFIC PARAMETERS
# ------------------------------------------------------------

TRAFFIC_PARAMETERS = [
    "Vehicle Count",
    "Average Speed",
    "Road Capacity",
    "Occupancy"
]


# ------------------------------------------------------------
# UNIQUE TRAFFIC CAUSE PARAMETERS
# ------------------------------------------------------------

TRAFFIC_CAUSE_PARAMETERS = [
    "Queue Length",
    "Lane Count",
    "Lane Blockage",
    "Blocked Lanes",
    "Road Work",
    "Pedestrian Count",
    "Turning Traffic",
    "Emergency Vehicles",
    "Weather Condition",
    "Incident Severity",
    "Current Green Time",
    "Event Crowd Level"
]


# ------------------------------------------------------------
# WEATHER CONDITIONS
# ------------------------------------------------------------

WEATHER_CONDITIONS = [
    "Clear",
    "Cloudy",
    "Rain",
    "Heavy Rain",
    "Fog"
]


# ------------------------------------------------------------
# INCIDENT LEVELS
# ------------------------------------------------------------

INCIDENT_LEVELS = [
    "None",
    "Minor",
    "Moderate",
    "Severe"
]


# ------------------------------------------------------------
# ROAD WORK STATUS
# ------------------------------------------------------------

ROAD_WORK_STATUS = [
    "No Road Work",
    "Minor Road Work",
    "Major Road Work"
]


# ------------------------------------------------------------
# SIGNAL OPTIMIZATION
# ------------------------------------------------------------

MIN_GREEN_TIME = 20
MAX_GREEN_TIME = 120

MIN_RED_TIME = 20
MAX_RED_TIME = 120


# ------------------------------------------------------------
# DASHBOARD SETTINGS
# ------------------------------------------------------------

DASHBOARD_TITLE = "AI-Powered Traffic Intelligence System"

DASHBOARD_SUBTITLE = (
    "Real-Time Monitoring • Congestion Prediction • "
    "Traffic Cause Detection • Smart Signal Optimization"
)


# ------------------------------------------------------------
# API SETTINGS
# ------------------------------------------------------------

API_TIMEOUT = 10

LIVE_TRAFFIC_ENABLED = True


# ------------------------------------------------------------
# SYSTEM FEATURES
# ------------------------------------------------------------

FEATURES = {
    "live_traffic": True,
    "traffic_prediction": True,
    "cause_detection": True,
    "signal_optimization": True,
    "area_comparison": True,
    "interactive_map": True,
    "incident_detection": True,
    "weather_analysis": True,
    "event_impact_analysis": True
}