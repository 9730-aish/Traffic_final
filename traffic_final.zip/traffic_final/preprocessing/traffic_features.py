# ============================================================
# TrafficTwin AI - Traffic Feature Engineering
# ============================================================

def calculate_vehicle_pressure(vehicle_count, road_capacity):
    """
    Calculates how much of the road capacity is being used.
    """

    if road_capacity <= 0:
        return 0

    pressure = (vehicle_count / road_capacity) * 100

    return round(min(pressure, 100), 2)


def calculate_speed_loss(current_speed, free_flow_speed):
    """
    Calculates percentage of speed lost compared to normal flow.
    """

    if free_flow_speed <= 0:
        return 0

    speed_loss = (
        (free_flow_speed - current_speed)
        / free_flow_speed
    ) * 100

    return round(max(0, min(speed_loss, 100)), 2)


def calculate_lane_blockage(blocked_lanes, lane_count):
    """
    Calculates percentage of blocked lanes.
    """

    if lane_count <= 0:
        return 0

    blockage = (blocked_lanes / lane_count) * 100

    return round(min(blockage, 100), 2)


def calculate_queue_pressure(queue_length):
    """
    Converts queue length into a normalized pressure score.
    """

    if queue_length <= 0:
        return 0

    # 100 vehicles is treated as maximum queue pressure
    pressure = (queue_length / 100) * 100

    return round(min(pressure, 100), 2)


def calculate_pedestrian_pressure(pedestrian_count):
    """
    Estimates traffic pressure caused by pedestrian activity.
    """

    if pedestrian_count <= 0:
        return 0

    pressure = (pedestrian_count / 200) * 100

    return round(min(pressure, 100), 2)


def calculate_turning_pressure(turning_traffic):
    """
    Converts turning traffic percentage into a pressure score.
    """

    if turning_traffic <= 0:
        return 0

    return round(min(turning_traffic, 100), 2)


def calculate_incident_pressure(incident_severity):
    """
    Converts incident severity into a numerical pressure score.
    """

    severity_scores = {
        "None": 0,
        "Minor": 25,
        "Moderate": 60,
        "Severe": 100
    }

    return severity_scores.get(
        incident_severity,
        0
    )


def calculate_weather_pressure(weather):
    """
    Estimates traffic impact caused by weather.
    """

    weather_scores = {
        "Clear": 0,
        "Cloudy": 10,
        "Rain": 35,
        "Heavy Rain": 65,
        "Fog": 80
    }

    return weather_scores.get(
        weather,
        0
    )


def calculate_event_pressure(event_crowd_level):
    """
    Estimates traffic impact caused by events/crowds.
    """

    event_scores = {
        "None": 0,
        "Low": 25,
        "Medium": 55,
        "High": 80,
        "Extreme": 100
    }

    return event_scores.get(
        event_crowd_level,
        0
    )


def create_traffic_features(data):
    """
    Creates all important traffic features
    from the supplied traffic data.
    """

    vehicle_count = data.get("vehicle_count", 0)
    road_capacity = data.get("road_capacity", 1)

    current_speed = data.get("current_speed", 0)
    free_flow_speed = data.get(
        "free_flow_speed",
        current_speed
    )

    blocked_lanes = data.get("blocked_lanes", 0)
    lane_count = data.get("lane_count", 1)

    queue_length = data.get("queue_length", 0)

    pedestrian_count = data.get(
        "pedestrian_count",
        0
    )

    turning_traffic = data.get(
        "turning_traffic",
        0
    )

    incident_severity = data.get(
        "incident_severity",
        "None"
    )

    weather = data.get(
        "weather",
        "Clear"
    )

    event_crowd_level = data.get(
        "event_crowd_level",
        "None"
    )

    features = {

        "vehicle_pressure":
            calculate_vehicle_pressure(
                vehicle_count,
                road_capacity
            ),

        "speed_loss":
            calculate_speed_loss(
                current_speed,
                free_flow_speed
            ),

        "lane_blockage_pressure":
            calculate_lane_blockage(
                blocked_lanes,
                lane_count
            ),

        "queue_pressure":
            calculate_queue_pressure(
                queue_length
            ),

        "pedestrian_pressure":
            calculate_pedestrian_pressure(
                pedestrian_count
            ),

        "turning_pressure":
            calculate_turning_pressure(
                turning_traffic
            ),

        "incident_pressure":
            calculate_incident_pressure(
                incident_severity
            ),

        "weather_pressure":
            calculate_weather_pressure(
                weather
            ),

        "event_pressure":
            calculate_event_pressure(
                event_crowd_level
            )
    }

    return features